rootProject.name = "netflix"
